<html>
    <head>
        <title>Paket Wisata</title>
    </head>
    <body>
        <h1>Form Pemesanan</h1>
        <form action="" method="POST">
            <label for="Nama">Nama Pemesan</label>
            <input type="text" name="namaPemesan">
            <label for="noHP">Nomor HP</label>
            <input type="text" name="noHP" id="">
            <input type="submit" value="submit" name="submit">
        </form>
    </body>
</html>

<?php
if (isset($_POST['submit'])) {
    $namaPemesan = $_POST['namaPemesan'];
    $noHP = $_POST['noHP'];

    echo "resume pemesan <br>";
    echo "Nama Pemesan : $namaPemesan <br>";
    echo "Nomor HP : $noHP <br>";
}
?>